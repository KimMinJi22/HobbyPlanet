package com.javalec.final_hobbyplanet.service;

import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javalec.final_hobbyplanet.dao.ApplyDAO;
import com.javalec.final_hobbyplanet.dto.ApplyDTO;

//DAO���� sql���� ������
@Service("ApplyService")
public class ApplyServiceImpl implements ApplyService {

	@Autowired
	private SqlSession sqlSession;

	@Override
	public ApplyDTO checkApply(HashMap<String, String> param) {
		ApplyDAO dao = sqlSession.getMapper(ApplyDAO.class);
		ApplyDTO dto = dao.checkApply(param);
		
		return dto;
	}

	@Override
	public void insertApply(HashMap<String, String> param) {
		ApplyDAO dao = sqlSession.getMapper(ApplyDAO.class);
		dao.insertApply(param);
	}

	@Override
	public void insertMemberApply(HashMap<String, String> param) {
		ApplyDAO dao = sqlSession.getMapper(ApplyDAO.class);
		dao.insertMemberApply(param);
	}

	@Override
	public void cancelApply(HashMap<String, String> param) {
		ApplyDAO dao = sqlSession.getMapper(ApplyDAO.class);
		dao.cancelApply(param);
	}

	@Override
	public void cancelMemberApply(HashMap<String, String> param) {
		ApplyDAO dao = sqlSession.getMapper(ApplyDAO.class);
		dao.cancelMemberApply(param);
	}

	@Override
	public void deleteApply(HashMap<String, String> param) {
		ApplyDAO dao = sqlSession.getMapper(ApplyDAO.class);
		dao.deleteApply(param);
	}

	@Override
	public ApplyDTO listApply(HashMap<String, String> param) {
		ApplyDAO dao = sqlSession.getMapper(ApplyDAO.class);
		ApplyDTO dto = dao.listApply(param);
		
		return dto;
	}
}