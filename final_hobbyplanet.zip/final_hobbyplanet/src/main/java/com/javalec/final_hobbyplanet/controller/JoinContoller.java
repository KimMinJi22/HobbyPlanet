package com.javalec.final_hobbyplanet.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.javalec.final_hobbyplanet.dto.ApplyDTO;
import com.javalec.final_hobbyplanet.dto.CategoryDTO;
import com.javalec.final_hobbyplanet.dto.JoinCommentDTO;
import com.javalec.final_hobbyplanet.dto.JoinDTO;
import com.javalec.final_hobbyplanet.dto.PageMaker;
import com.javalec.final_hobbyplanet.dto.SearchCriteria;
import com.javalec.final_hobbyplanet.service.ApplyService;
import com.javalec.final_hobbyplanet.service.CategoryService;
import com.javalec.final_hobbyplanet.service.JoinCommentService;
import com.javalec.final_hobbyplanet.service.JoinService;
import com.javalec.final_hobbyplanet.service.MessageService;

// Service�� �޼ҵ���� ȣ��
@Controller
public class JoinContoller {
	
	@Autowired JoinService j_service;
	@Autowired ApplyService a_service;
	@Autowired CategoryService c_service;
	@Autowired MessageService m_service;
	@Autowired public HttpSession session;
	@Autowired JoinCommentService jc_service;
	
	// ��� ����
	@RequestMapping("/join/listJoin")
	public String listJoin(Model model, SearchCriteria searchCriteria) {
		ArrayList<JoinDTO> list = j_service.listJoinPaging(searchCriteria);

		// �����Ϸ�
		for(int i = 0; i < list.size(); i++) {
			Date day = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String today = sdf.format(day);
			String dday = list.get(i).getJ_Dday().toString().substring(0, 10);
			
			// ������¥�� ������ ���
			if((dday).equals(today)) {
				j_service.endJoin(list.get(i).getJ_idx());
			}

			// �ִ� �ο��� ���� �ο��� ���� ���
			if(list.get(i).getJ_maxmem() == list.get(i).getJ_nowmem()) {
				j_service.endJoin(list.get(i).getJ_idx());
			}
		}
		
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCriteria(searchCriteria);
		pageMaker.setTotal(j_service.countJoin(searchCriteria));
		model.addAttribute("pageMaker", pageMaker);
		
		model.addAttribute("listJoin", list);

		return "join/listJoin";
	}
	
	// �� �ۼ� ��
	@RequestMapping("/join/writeJoin")
	public String writeJoin(Model model, SearchCriteria searchCriteria) {
		ArrayList<CategoryDTO> c_list = c_service.listCity();
		ArrayList<CategoryDTO> h_list = c_service.listHobby();
		model.addAttribute("Citys", c_list);
		model.addAttribute("Hobbys", h_list);
		
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCriteria(searchCriteria);
		pageMaker.setTotal(j_service.countJoin(searchCriteria));
		model.addAttribute("pageMaker", pageMaker);
		
		return "join/writeJoin";
	}
	
	// �� �ۼ�
	@RequestMapping("/join/writeJoin_ok")
	public String writeJoin_ok(@RequestParam HashMap<String, String> param) throws UnsupportedEncodingException {
		String encodedParam = URLEncoder.encode(param.get("keyword"), "UTF-8");

		j_service.writeJoin(param);
		
		return "redirect:listJoin?page="+param.get("page")+"&perPageNum="+param.get("perPageNum")+"&searchType="+param.get("searchType")+"&keyword="+encodedParam;
	}
	
	// �󼼺���
	@RequestMapping("/join/viewJoin")
	public String viewJoin(@RequestParam HashMap<String, String> param, Model model, SearchCriteria searchCriteria) {
		j_service.upCountJoin(param);
		
		ArrayList<ApplyDTO> list = a_service.listApply(param);
		
		for(int i = 0; i < list.size(); i++) {
			if((list.get(i).getAp_id()).equals((session.getAttribute("u_id")))) {
				model.addAttribute("apply", "yes");
			}
		}

		JoinDTO j_dto = j_service.viewJoin(param);
		model.addAttribute("viewJoin", j_dto);
		
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCriteria(searchCriteria);
		pageMaker.setTotal(j_service.countJoin(searchCriteria));
		model.addAttribute("pageMaker", pageMaker);
		
		ArrayList<JoinCommentDTO> dtoc = jc_service.listJoinComment(param);
		model.addAttribute("listComment", dtoc);
		
		return "join/viewJoin";
	}
	
	// �� ���� ��
	@RequestMapping("/join/editJoin")
	public String editJoin(@RequestParam HashMap<String, String> param, Model model, SearchCriteria searchCriteria) {
		ArrayList<CategoryDTO> c_list = c_service.listCity();
		ArrayList<CategoryDTO> h_list = c_service.listHobby();
		model.addAttribute("Citys", c_list);
		model.addAttribute("Hobbys", h_list);
		
		JoinDTO dto = j_service.viewJoin(param);
		model.addAttribute("viewJoin", dto);
		
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCriteria(searchCriteria);
		pageMaker.setTotal(j_service.countJoin(searchCriteria));
		model.addAttribute("pageMaker", pageMaker);
		
		return "join/editJoin";
	}
	
	// �� ����
	@RequestMapping("/join/editJoin_ok")
	public String editJoin_ok(@RequestParam HashMap<String, String> param) throws UnsupportedEncodingException {
		String encodedParam = URLEncoder.encode(param.get("keyword"), "UTF-8");

		j_service.editJoin(param);
		
		return "redirect:viewJoin?j_idx="+ param.get("j_idx") +"&page="+param.get("page")+"&perPageNum="+param.get("perPageNum")+"&searchType="+param.get("searchType")+"&keyword="+encodedParam;
	}
	
	// �� ���� ��
	@RequestMapping("/join/deleteJoin")
	public String deleteJoin(@RequestParam HashMap<String, String> param, Model model, SearchCriteria searchCriteria) {
		JoinDTO dto = j_service.viewJoin(param);
		model.addAttribute("viewJoin", dto);
		
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCriteria(searchCriteria);
		pageMaker.setTotal(j_service.countJoin(searchCriteria));
		model.addAttribute("pageMaker", pageMaker);
		
		return "join/deleteJoin";
	}
	
	// ����
	@RequestMapping("/join/deleteJoin_ok")
	public String deleteJoin_ok(@RequestParam HashMap<String, String> param) throws UnsupportedEncodingException {
		String encodedParam = URLEncoder.encode(param.get("keyword"), "UTF-8");

		jc_service.deleteJoinComment(param);
		a_service.deleteApply(param);
		j_service.deleteJoin(param);
	
		return "redirect:listJoin?page="+param.get("page")+"&perPageNum="+param.get("perPageNum")+"&searchType="+param.get("searchType")+"&keyword="+encodedParam;
	}
	
	// �����ϱ�
	@RequestMapping("/join/applyJoin")
	public String applyJoin(@RequestParam HashMap<String, String> param, Model model) {
		ApplyDTO dto = a_service.checkApply(param);
		
		if(dto == null) {
			a_service.insertApply(param);
			a_service.insertMemberApply(param);
			m_service.writeMessage(param);
			model.addAttribute("apply", a_service.checkApply(param));
		}
		
		else {
			a_service.cancelApply(param);
			a_service.cancelMemberApply(param);
			m_service.writeMessage(param);
		}

		return "redirect:viewJoin?j_idx=" + param.get("j_idx");
	}
	
	// ��� �ۼ�
	@RequestMapping("/join/comment_ok")
	public String writeJoinComment(@RequestParam HashMap<String, String> param) throws UnsupportedEncodingException {
		String encodedParam = URLEncoder.encode(param.get("keyword"), "UTF-8");

		jc_service.insertJoinComment(param);
      
		return "redirect:viewJoin?j_idx="+param.get("j_idx")+"&page="+param.get("page")+"&perPageNum="+param.get("perPageNum")+"&searchType="+param.get("searchType")+"&keyword="+encodedParam;
	}
   
	// ��� ����
	@RequestMapping("/join/modifyComment_ok")
	public String modifyCommentJoin(@RequestParam HashMap<String, String> param) throws UnsupportedEncodingException {
		String encodedParam = URLEncoder.encode(param.get("keyword"), "UTF-8");

		jc_service.editJoinComment(param);
         
		return "redirect:viewJoin?j_idx="+param.get("j_idx")+"&page="+param.get("page")+"&perPageNum="+param.get("perPageNum")+"&searchType="+param.get("searchType")+"&keyword="+encodedParam;
	}
  
	// ��� ����
	@RequestMapping("/join/deleteComment_ok")
	public String deleteJoinComment(@RequestParam HashMap<String, String> param) throws UnsupportedEncodingException {
		String encodedParam = URLEncoder.encode(param.get("keyword"), "UTF-8");

		jc_service.deleteComment(param);
      
		return "redirect:viewJoin?j_idx="+param.get("j_idx")+"&page="+param.get("page")+"&perPageNum="+param.get("perPageNum")+"&searchType="+param.get("searchType")+"&keyword="+encodedParam;
	}
}