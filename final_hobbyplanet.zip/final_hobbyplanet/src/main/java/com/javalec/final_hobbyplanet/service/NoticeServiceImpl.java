package com.javalec.final_hobbyplanet.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javalec.final_hobbyplanet.dao.NoticeDAO;
import com.javalec.final_hobbyplanet.dto.NoticeDTO;
import com.javalec.final_hobbyplanet.dto.SearchCriteria;

@Service("NoticeService")
public class NoticeServiceImpl implements NoticeService {
	
	@Autowired
	private SqlSession sqlSession;

	@Override
	public void writeNotice(HashMap<String, String> param) {
		NoticeDAO dao = sqlSession.getMapper(NoticeDAO.class);
		dao.writeNotice(param);
	}

	@Override
	public NoticeDTO showNotice(HashMap<String, String> param) {
		NoticeDAO dao = sqlSession.getMapper(NoticeDAO.class);
		NoticeDTO dto = dao.showNotice(param);
		return dto;
	}

	@Override
	public void upCount(HashMap<String, String> param) {
		NoticeDAO dao = sqlSession.getMapper(NoticeDAO.class);
		dao.upCount(param);
	}

	@Override
	public void editNotice(HashMap<String, String> param) {
		NoticeDAO dao = sqlSession.getMapper(NoticeDAO.class);
		dao.editNotice(param);
	}

	@Override
	public void deleteNotice(HashMap<String, String> param) {
		NoticeDAO dao = sqlSession.getMapper(NoticeDAO.class);
		dao.deleteNotice(param);;
	}

	@Override
	public ArrayList<NoticeDTO> listNoticePaging(SearchCriteria searchCriteria) {
		NoticeDAO dao = sqlSession.getMapper(NoticeDAO.class);
		ArrayList<NoticeDTO> list = dao.listNoticePaging(searchCriteria);
		return list;
	}

	@Override
	public int countNotice(SearchCriteria searchCriteria) {
		NoticeDAO dao = sqlSession.getMapper(NoticeDAO.class);
		int total = dao.countNotice(searchCriteria);
		return total;
	}
}
