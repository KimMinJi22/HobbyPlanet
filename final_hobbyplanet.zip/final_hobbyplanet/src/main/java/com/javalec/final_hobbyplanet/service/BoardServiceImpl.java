package com.javalec.final_hobbyplanet.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javalec.final_hobbyplanet.dao.BoardDAO;
import com.javalec.final_hobbyplanet.dto.BoardDTO;
import com.javalec.final_hobbyplanet.dto.SearchCriteria;

@Service("BoardService")
public class BoardServiceImpl implements BoardService{
	
	@Autowired
	private SqlSession sqlsession;
	
	@Override
	public void insertBoard(HashMap<String, String> param) {
		BoardDAO dao = sqlsession.getMapper(BoardDAO.class);
		dao.insertBoard(param);
	}

	@Override
	public ArrayList<BoardDTO> listBoard(SearchCriteria searchCriteria) {
		BoardDAO dao = sqlsession.getMapper(BoardDAO.class);
		ArrayList<BoardDTO> dtos = dao.listBoard(searchCriteria);
		
		return dtos;
	}

	@Override
	public int countBoard(SearchCriteria searchCriteria) {
		BoardDAO dao = sqlsession.getMapper(BoardDAO.class);
		int total = dao.countBoard(searchCriteria);
		
		return total;
	}

	@Override
	public void hitBoard(HashMap<String, String> param) {
		BoardDAO dao = sqlsession.getMapper(BoardDAO.class);
		dao.hitBoard(param);
	}

	@Override
	public BoardDTO getBoard(HashMap<String, String> param) {
		BoardDAO dao = sqlsession.getMapper(BoardDAO.class);
		BoardDTO dto = dao.getBoard(param);
		
		return dto;
	}

	@Override
	public void deleteBoard(HashMap<String, String> param) {
		BoardDAO dao = sqlsession.getMapper(BoardDAO.class);
		dao.deleteBoard(param);
	}

	@Override
	public void editBoard(HashMap<String, String> param) {
		BoardDAO dao = sqlsession.getMapper(BoardDAO.class);
		dao.editBoard(param);
	}
}
