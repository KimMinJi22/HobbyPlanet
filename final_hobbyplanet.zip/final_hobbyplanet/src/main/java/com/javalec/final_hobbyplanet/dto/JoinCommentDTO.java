package com.javalec.final_hobbyplanet.dto;

import java.sql.Timestamp;

public class JoinCommentDTO {

   private int jc_idx;
   private int jc_bidx;
   private String jc_id;
   private String jc_nickname;
   private String jc_content;
   private Timestamp jc_date;
	   
	   public int getJc_idx() {
	      return jc_idx;
	   }
	   public void setJc_idx(int jc_idx) {
	      this.jc_idx = jc_idx;
	   }
	   public int getJc_bidx() {
	      return jc_bidx;
	   }
	   public void setJc_bidx(int jc_bidx) {
	      this.jc_bidx = jc_bidx;
	   }
	   public String getJc_id() {
	      return jc_id;
	   }
	   public void setJc_id(String jc_id) {
	      this.jc_id = jc_id;
	   }
	   public String getJc_nickname() {
	      return jc_nickname;
	   }
	   public void setJc_nickname(String jc_nickname) {
	      this.jc_nickname = jc_nickname;
	   }
	   public String getJc_content() {
	      return jc_content;
	   }
	   public void setJc_content(String jc_content) {
	      this.jc_content = jc_content;
	   }
	   public Timestamp getJc_date() {
	      return jc_date;
	   }
	   public void setJc_date(Timestamp jc_date) {
	      this.jc_date = jc_date;
	   }
}