package com.javalec.final_hobbyplanet.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.javalec.final_hobbyplanet.dto.NoticeDTO;
import com.javalec.final_hobbyplanet.dto.PageMaker;
import com.javalec.final_hobbyplanet.dto.SearchCriteria;
import com.javalec.final_hobbyplanet.service.NoticeService;

@Controller
public class NoticeController {
	
	@Autowired
	private NoticeService service;
	
	@RequestMapping("/notice/listNotice")
	public String listNotice(Model model, SearchCriteria searchCriteria) {
		ArrayList<NoticeDTO> list = service.listNoticePaging(searchCriteria);
		model.addAttribute("listNotice", list);
		
		int total = service.countNotice(searchCriteria);
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCriteria(searchCriteria);
		pageMaker.setTotal(total);
		model.addAttribute("pageMaker", pageMaker);
		
		return "/notice/listNotice";
	}
	
	@RequestMapping("/notice/writeNotice")
	public String write(Model model, SearchCriteria searchCriteria) {
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCriteria(searchCriteria);
		pageMaker.setTotal(service.countNotice(searchCriteria));
		model.addAttribute("pageMaker", pageMaker);
		
		return "/notice/writeNotice";
	}
	
	@RequestMapping("/notice/writeNotice_ok")
	public String writeNotice(@RequestParam HashMap<String, String> param) throws UnsupportedEncodingException {
		service.writeNotice(param);
		String encodedParam = URLEncoder.encode(param.get("keyword"), "UTF-8");
		
		return "redirect:listNotice?page="+param.get("page")+"&perPageNum="+param.get("perPageNum")+"&searchType="+param.get("searchType")+"&keyword="+encodedParam;
	}
	
	@RequestMapping("/notice/showNotice")
	public String showNotice(@RequestParam HashMap<String, String> param, Model model, SearchCriteria searchCriteria) {
		service.upCount(param); // �Խñ� ��ȸ���� +1 �ϴ� ����
		
		NoticeDTO dto = service.showNotice(param);
		model.addAttribute("show", dto);
		
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCriteria(searchCriteria);
		pageMaker.setTotal(service.countNotice(searchCriteria));
		model.addAttribute("pageMaker", pageMaker);
		
		return "/notice/showNotice";
	}
	
	@RequestMapping("/notice/editNotice")
	public String edit(@RequestParam HashMap<String, String> param, Model model, SearchCriteria searchCriteria) {
		NoticeDTO dto = service.showNotice(param);
		model.addAttribute("show", dto);
		
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCriteria(searchCriteria);
		pageMaker.setTotal(service.countNotice(searchCriteria));
		model.addAttribute("pageMaker", pageMaker);
		
		return "/notice/editNotice";
	}
	
	@RequestMapping("/notice/editNotice_ok")
	public String editNotice(@RequestParam HashMap<String, String> param, Model model) throws UnsupportedEncodingException {
		service.editNotice(param);
		String encodedParam = URLEncoder.encode(param.get("keyword"), "UTF-8");
		
		return "redirect:listNotice?page="+param.get("page")+"&perPageNum="+param.get("perPageNum")+"&searchType="+param.get("searchType")+"&keyword="+encodedParam;
	}
	
	@RequestMapping("/notice/deleteNotice_ok")
	public String deleteNotice(@RequestParam HashMap<String, String> param, Model model) throws UnsupportedEncodingException {
		service.deleteNotice(param);
		String encodedParam = URLEncoder.encode(param.get("keyword"), "UTF-8");
		
		return "redirect:listNotice?page="+param.get("page")+"&perPageNum="+param.get("perPageNum")+"&searchType="+param.get("searchType")+"&keyword="+encodedParam;
	}
	
}
