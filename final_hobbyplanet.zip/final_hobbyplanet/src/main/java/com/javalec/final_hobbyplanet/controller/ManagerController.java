package com.javalec.final_hobbyplanet.controller;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.javalec.final_hobbyplanet.dto.BoardDTO;
import com.javalec.final_hobbyplanet.dto.CategoryDTO;
import com.javalec.final_hobbyplanet.dto.JoinDTO;
import com.javalec.final_hobbyplanet.dto.PageMaker;
import com.javalec.final_hobbyplanet.dto.SearchCriteria;
import com.javalec.final_hobbyplanet.dto.UserDTO;
import com.javalec.final_hobbyplanet.service.BoardService;
import com.javalec.final_hobbyplanet.service.CategoryService;
import com.javalec.final_hobbyplanet.service.JoinService;
import com.javalec.final_hobbyplanet.service.ManagerService;
import com.javalec.final_hobbyplanet.service.UserService;

@Controller
public class ManagerController {

	@Autowired private ManagerService mService;
	@Autowired private UserService uService;
	@Autowired private CategoryService cService;
	@Autowired private JoinService jService;
	@Autowired private BoardService bService;
	
	@RequestMapping("/manager/manager")
	public String main(Model model, SearchCriteria searchCriteria) {
		int cntUser = mService.countUser(searchCriteria);
		int cntRegdate = mService.countRegdate();
		int cntJoin = jService.countJoin(searchCriteria);
		int cntBoard = bService.countBoard(searchCriteria);
		
		model.addAttribute("cntUser", cntUser);
		model.addAttribute("cntRegdate", cntRegdate);
		model.addAttribute("cntJoin", cntJoin);
		model.addAttribute("cntBoard", cntBoard);
		
		ArrayList<CategoryDTO> listCity = cService.listCity();
		ArrayList<CategoryDTO> listHobby = cService.listHobby();
		
		model.addAttribute("Citys", listCity);
		model.addAttribute("Hobbys", listHobby);

		return "manager/manager";
	}
	
	@RequestMapping("/manager/insertCity_ok")
	public String insertCity(@RequestParam HashMap<String, String> param) {
		cService.insertCity(param);
		
		return "redirect:manager";
	}
	
	@RequestMapping("/manager/deleteCity_ok")
	public String deleteCity(@RequestParam HashMap<String, String> param) {
		cService.deleteCity(param);
		
		return "redirect:manager";
	}
	
	@RequestMapping("/manager/insertHobby_ok")
	public String insertHobby(@RequestParam HashMap<String, String> param) {
		cService.insertHobby(param);
		
		return "redirect:manager";
	}
	
	@RequestMapping("/manager/deleteHobby_ok")
	public String deleteHobby(@RequestParam HashMap<String, String> param) {
		cService.deleteHobby(param);
		
		return "redirect:manager";
	}
	
	@RequestMapping("/manager/listUser")
	public String listUser(Model model, SearchCriteria searchCriteria) {
		ArrayList<UserDTO> list = mService.listUserPaging(searchCriteria);
		model.addAttribute("listUser", list);
		
		int total = mService.countUser(searchCriteria);
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCriteria(searchCriteria);
		pageMaker.setTotal(total);
		model.addAttribute("pageMaker", pageMaker);

		return "manager/listUser";
	}
	
	@RequestMapping("/manager/showUser")
	public String showUser(@RequestParam HashMap<String, String> param, Model model) {
		UserDTO dto = uService.showUser(param);
		model.addAttribute("showUser", dto);
		
		return "manager/showUser";
	}

	@RequestMapping("/manager/listJoin")
	public String listJoin(Model model, SearchCriteria searchCriteria) {
		ArrayList<JoinDTO> list = jService.listJoinPaging(searchCriteria);
		model.addAttribute("listJoin", list);
		
		int total = jService.countJoin(searchCriteria);
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCriteria(searchCriteria);
		pageMaker.setTotal(total);
		model.addAttribute("pageMaker", pageMaker);
		
		return "manager/listJoin";
	}

	@RequestMapping("/manager/listBoard")
	public String listBoard(Model model, SearchCriteria searchCriteria) {
		ArrayList<BoardDTO> list = bService.listBoard(searchCriteria);
		model.addAttribute("listBoard", list);
		
		int total = bService.countBoard(searchCriteria);
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCriteria(searchCriteria);
		pageMaker.setTotal(total);
		model.addAttribute("pageMaker", pageMaker);

		return "manager/listBoard";
	}
	
}
